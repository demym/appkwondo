var rta_template={
			active: true,
			match: {},
			result: "0-0",
			round: "1",
			paused: true,
			running: false,
            fineround: true
		}